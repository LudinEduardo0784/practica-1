/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package evaluacionaprobo_reprobo;

/**
 *
 * @author 14-cf2074
 */
public class EvaluacionAprobo_reprobo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Datos de los estudiantes
        String[] nombres = {"Misael Lopez", "Keysi Fuentes"};
        int[] notas = {55, 96};

        for (int i = 0; i < nombres.length; i++) {
            String nombre = nombres[i];
            int nota = notas[i];

            String resultado;
            if (nota >= 60) {
                resultado = "Aprobado";
            } else {
                resultado = "Reprobado";
            }

            // Imprimir los resultados
            System.out.println("Nombre del estudiante: " + nombre);
            System.out.println("Nota: " + nota);
            System.out.println("Resultado: " + resultado);
            System.out.println();
        }
    }
}